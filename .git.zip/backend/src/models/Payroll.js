// Payroll Data Model Representation
class Payroll {
  constructor(id, employeeId, month, year, basicSalary, bonuses = 0, deductions = 0, netSalary, status = 'pending') {
    this.id = id;
    this.employeeId = employeeId;
    this.month = month;
    this.year = year;
    this.basicSalary = basicSalary;
    this.bonuses = bonuses;
    this.deductions = deductions;
    this.netSalary = netSalary;
    this.status = status;
  }
}

module.exports = Payroll;
