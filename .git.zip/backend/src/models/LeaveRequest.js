// Leave Request Data Model Representation
class LeaveRequest {
  constructor(id, employeeId, leaveType, startDate, endDate, reason, status = 'pending', approvedBy = null) {
    this.id = id;
    this.employeeId = employeeId;
    this.leaveType = leaveType;
    this.startDate = startDate;
    this.endDate = endDate;
    this.reason = reason;
    this.status = status;
    this.approvedBy = approvedBy;
  }
}

module.exports = LeaveRequest;
