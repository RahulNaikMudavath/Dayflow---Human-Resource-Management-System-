// User Data Model Representation
class User {
  constructor(id, email, passwordHash, role = 'employee', isVerified = false) {
    this.id = id;
    this.email = email;
    this.passwordHash = passwordHash;
    this.role = role;
    this.isVerified = isVerified;
  }
}

module.exports = User;
