// Employee Data Model Representation
class Employee {
  constructor(id, userId, firstName, lastName, department, designation, phone, dateOfJoining, salary) {
    this.id = id;
    this.userId = userId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.department = department;
    this.designation = designation;
    this.phone = phone;
    this.dateOfJoining = dateOfJoining;
    this.salary = salary;
  }
}

module.exports = Employee;
