// Attendance Data Model Representation
class Attendance {
  constructor(id, employeeId, date, checkIn, checkOut, status = 'present') {
    this.id = id;
    this.employeeId = employeeId;
    this.date = date;
    this.checkIn = checkIn;
    this.checkOut = checkOut;
    this.status = status;
  }
}

module.exports = Attendance;
