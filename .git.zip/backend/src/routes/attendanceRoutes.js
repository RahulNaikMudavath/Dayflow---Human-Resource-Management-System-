const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.use(authMiddleware);

router.post('/check-in', attendanceController.checkIn);
router.post('/check-out', attendanceController.checkOut);
router.get('/my-records', attendanceController.getMyAttendance);
router.get('/all', roleMiddleware(['admin', 'hr']), attendanceController.getAllAttendance);

module.exports = router;
