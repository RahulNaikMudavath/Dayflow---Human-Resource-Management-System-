const express = require('express');
const router = express.Router();
const leaveController = require('../controllers/leaveController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.use(authMiddleware);

router.post('/', leaveController.applyLeave);
router.get('/my-leaves', leaveController.getMyLeaves);
router.get('/pending', roleMiddleware(['admin', 'hr']), leaveController.getPendingLeaves);
router.put('/:id/status', roleMiddleware(['admin', 'hr']), leaveController.updateLeaveStatus);

module.exports = router;
