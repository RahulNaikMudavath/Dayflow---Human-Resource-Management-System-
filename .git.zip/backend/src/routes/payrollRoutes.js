const express = require('express');
const router = express.Router();
const payrollController = require('../controllers/payrollController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.use(authMiddleware);

router.get('/my-slips', payrollController.getMyPayslips);
router.post('/generate', roleMiddleware(['admin', 'hr']), payrollController.generatePayroll);

module.exports = router;
