exports.applyLeave = async (req, res, next) => {
  try {
    res.status(201).json({ message: 'Leave request submitted', request: req.body });
  } catch (error) {
    next(error);
  }
};

exports.getMyLeaves = async (req, res, next) => {
  try {
    res.json([
      { id: 1, leaveType: 'casual', startDate: '2026-08-27', endDate: '2026-08-29', status: 'pending' }
    ]);
  } catch (error) {
    next(error);
  }
};

exports.getPendingLeaves = async (req, res, next) => {
  try {
    res.json([
      { id: 1, employeeName: 'John Doe', leaveType: 'casual', startDate: '2026-08-27', endDate: '2026-08-29', reason: 'Family vacation', status: 'pending' }
    ]);
  } catch (error) {
    next(error);
  }
};

exports.updateLeaveStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    res.json({ message: `Leave request ${id} updated to ${status}` });
  } catch (error) {
    next(error);
  }
};
