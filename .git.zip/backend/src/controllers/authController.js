const jwt = require('jsonwebtoken');

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    // Stub response for authentication
    if (email === 'admin@dayflow.com') {
      const token = jwt.sign({ id: 1, email, role: 'admin' }, process.env.JWT_SECRET || 'dayflow_super_secret_jwt_key_2026', { expiresIn: '1d' });
      return res.json({ token, user: { id: 1, email, role: 'admin', firstName: 'System', lastName: 'Admin' } });
    }
    const token = jwt.sign({ id: 2, email, role: 'employee' }, process.env.JWT_SECRET || 'dayflow_super_secret_jwt_key_2026', { expiresIn: '1d' });
    res.json({ token, user: { id: 2, email, role: 'employee', firstName: 'John', lastName: 'Doe' } });
  } catch (error) {
    next(error);
  }
};

exports.signup = async (req, res, next) => {
  try {
    const { email, password, firstName, lastName } = req.body;
    res.status(201).json({ message: 'User registered successfully', user: { email, firstName, lastName } });
  } catch (error) {
    next(error);
  }
};

exports.verifyEmail = async (req, res, next) => {
  try {
    const { token } = req.body;
    res.json({ message: 'Email verified successfully' });
  } catch (error) {
    next(error);
  }
};
