exports.getAllEmployees = async (req, res, next) => {
  try {
    const employees = [
      { id: 1, firstName: 'System', lastName: 'Admin', department: 'Management', designation: 'HR Admin', phone: '+1234567890' },
      { id: 2, firstName: 'John', lastName: 'Doe', department: 'Engineering', designation: 'Software Engineer', phone: '+1987654321' }
    ];
    res.json(employees);
  } catch (error) {
    next(error);
  }
};

exports.getEmployeeById = async (req, res, next) => {
  try {
    const { id } = req.params;
    res.json({ id: parseInt(id), firstName: 'John', lastName: 'Doe', department: 'Engineering', designation: 'Software Engineer' });
  } catch (error) {
    next(error);
  }
};

exports.updateEmployee = async (req, res, next) => {
  try {
    const { id } = req.params;
    res.json({ message: 'Employee updated successfully', updated: req.body });
  } catch (error) {
    next(error);
  }
};
