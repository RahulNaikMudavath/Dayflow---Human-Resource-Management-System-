import React from 'react';

const Button = ({ children, variant = 'primary', onClick, type = 'button', style = {}, disabled = false }) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'secondary':
        return { backgroundColor: '#E8F1F4', color: '#134E4A', border: '1px solid #5EEAD4' };
      case 'danger':
        return { backgroundColor: '#DC2626', color: '#FFFFFF', border: 'none' };
      case 'outline':
        return { backgroundColor: 'transparent', color: '#0D9488', border: '1px solid #0D9488' };
      default:
        return { backgroundColor: '#0D9488', color: '#FFFFFF', border: 'none' };
    }
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '10px 18px',
        borderRadius: '6px',
        fontWeight: 600,
        fontSize: '14px',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '8px',
        transition: 'opacity 150ms ease',
        opacity: disabled ? 0.6 : 1,
        ...getVariantStyles(),
        ...style,
      }}
    >
      {children}
    </button>
  );
};

export default Button;
