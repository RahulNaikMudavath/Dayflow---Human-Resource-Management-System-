import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { LogOut, User } from 'lucide-react';

const Navbar = () => {
  const { user, logout } = useAuth();

  return (
    <header style={{
      height: '60px',
      backgroundColor: '#FFFFFF',
      borderBottom: '1px solid #E2E8F0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          backgroundColor: '#0D9488',
          color: '#FFFFFF',
          padding: '6px 12px',
          borderRadius: '6px',
          fontWeight: 700,
          fontSize: '18px'
        }}>
          Dayflow
        </div>
        <span style={{ fontWeight: 600, color: '#134E4A' }}>HRMS</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {user && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px' }}>
              <User size={18} color="#0D9488" />
              <span>{user.firstName || user.email}</span>
              <span style={{
                backgroundColor: user.role === 'admin' ? '#D97706' : '#2DD4BF',
                color: user.role === 'admin' ? '#FFFFFF' : '#0F172A',
                fontSize: '11px',
                padding: '2px 8px',
                borderRadius: '12px',
                fontWeight: 600,
                textTransform: 'uppercase'
              }}>
                {user.role}
              </span>
            </div>
            <button
              onClick={logout}
              style={{
                background: 'none',
                border: 'none',
                color: '#DC2626',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                fontSize: '14px',
                fontWeight: 500
              }}
            >
              <LogOut size={16} /> Logout
            </button>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
