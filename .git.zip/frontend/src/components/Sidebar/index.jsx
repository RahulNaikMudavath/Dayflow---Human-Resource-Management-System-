import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LayoutDashboard, Users, CalendarCheck, FileText, DollarSign, UserCheck } from 'lucide-react';

const Sidebar = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.role === 'hr';

  const linkStyle = ({ isActive }) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '10px 16px',
    borderRadius: '6px',
    color: isActive ? '#FFFFFF' : '#475569',
    backgroundColor: isActive ? '#0D9488' : 'transparent',
    fontWeight: isActive ? 600 : 400,
    fontSize: '14px',
    marginBottom: '4px',
    transition: 'all 150ms ease'
  });

  return (
    <aside style={{
      width: '240px',
      backgroundColor: '#FFFFFF',
      borderRight: '1px solid #E2E8F0',
      minHeight: 'calc(100vh - 60px)',
      padding: '16px'
    }}>
      <nav>
        <div style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', marginBottom: '8px', paddingLeft: '8px' }}>
          Employee Portal
        </div>
        <NavLink to="/dashboard" style={linkStyle}>
          <LayoutDashboard size={18} /> Dashboard
        </NavLink>
        <NavLink to="/profile" style={linkStyle}>
          <UserCheck size={18} /> Profile
        </NavLink>
        <NavLink to="/attendance" style={linkStyle}>
          <CalendarCheck size={18} /> Attendance
        </NavLink>
        <NavLink to="/leaves" style={linkStyle}>
          <FileText size={18} /> Leave Requests
        </NavLink>
        <NavLink to="/payroll" style={linkStyle}>
          <DollarSign size={18} /> My Payroll
        </NavLink>

        {isAdmin && (
          <>
            <div style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', marginTop: '24px', marginBottom: '8px', paddingLeft: '8px' }}>
              Admin Portal
            </div>
            <NavLink to="/admin/dashboard" style={linkStyle}>
              <LayoutDashboard size={18} /> Overview
            </NavLink>
            <NavLink to="/admin/employees" style={linkStyle}>
              <Users size={18} /> Employees
            </NavLink>
            <NavLink to="/admin/attendance" style={linkStyle}>
              <CalendarCheck size={18} /> All Attendance
            </NavLink>
            <NavLink to="/admin/leaves" style={linkStyle}>
              <FileText size={18} /> Leave Approvals
            </NavLink>
            <NavLink to="/admin/payroll" style={linkStyle}>
              <DollarSign size={18} /> Run Payroll
            </NavLink>
          </>
        )}
      </nav>
    </aside>
  );
};

export default Sidebar;
