import React from 'react';

const Card = ({ title, children, style = {} }) => {
  return (
    <div style={{
      backgroundColor: '#FFFFFF',
      borderRadius: '8px',
      border: '1px solid #E2E8F0',
      padding: '20px',
      marginBottom: '16px',
      ...style,
    }}>
      {title && (
        <h3 style={{
          fontSize: '16px',
          fontWeight: 600,
          color: '#134E4A',
          marginBottom: '12px',
          borderBottom: '1px solid #F1F5F9',
          paddingBottom: '8px'
        }}>
          {title}
        </h3>
      )}
      {children}
    </div>
  );
};

export default Card;
