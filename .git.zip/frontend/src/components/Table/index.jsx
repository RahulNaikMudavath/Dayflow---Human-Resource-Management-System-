import React from 'react';

const Table = ({ headers = [], data = [], renderRow }) => {
  return (
    <div style={{ overflowX: 'auto', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', backgroundColor: '#FFFFFF', textAlign: 'left' }}>
        <thead>
          <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid #E2E8F0' }}>
            {headers.map((head, idx) => (
              <th key={idx} style={{ padding: '12px 16px', fontSize: '13px', fontWeight: 600, color: '#475569' }}>
                {head}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={headers.length} style={{ padding: '24px', textAlign: 'center', color: '#94A3B8' }}>
                No records found.
              </td>
            </tr>
          ) : (
            data.map((row, idx) => (
              <tr key={idx} style={{ borderBottom: '1px solid #F1F5F9' }}>
                {renderRow(row, idx)}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
