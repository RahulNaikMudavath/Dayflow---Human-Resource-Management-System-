const API_URL = 'http://localhost:5000/api/leaves';

export const leaveService = {
  applyLeave: async (data) => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });
    return res.json();
  },
  getMyLeaves: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/my-leaves`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  getPending: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/pending`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  updateStatus: async (id, status) => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/${id}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    });
    return res.json();
  },
};
