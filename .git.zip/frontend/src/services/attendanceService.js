const API_URL = 'http://localhost:5000/api/attendance';

export const attendanceService = {
  checkIn: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/check-in`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  checkOut: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/check-out`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  getMyRecords: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/my-records`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  getAllRecords: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/all`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
};
