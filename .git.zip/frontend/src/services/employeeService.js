const API_URL = 'http://localhost:5000/api/employees';

export const employeeService = {
  getAll: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(API_URL, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  getById: async (id) => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  update: async (id, data) => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });
    return res.json();
  },
};
