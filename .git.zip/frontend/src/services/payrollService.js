const API_URL = 'http://localhost:5000/api/payroll';

export const payrollService = {
  getMySlips: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/my-slips`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
  generate: async () => {
    const token = localStorage.getItem('dayflow_token');
    const res = await fetch(`${API_URL}/generate`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
};
