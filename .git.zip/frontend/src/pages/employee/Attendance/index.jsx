import React, { useState } from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import Table from '../../../components/Table';
import { attendanceService } from '../../../services/attendanceService';

const Attendance = () => {
  const [msg, setMsg] = useState('');
  const sampleRecords = [
    { date: '2026-08-22', checkIn: '09:00 AM', checkOut: '05:00 PM', status: 'Present' },
    { date: '2026-08-21', checkIn: '09:12 AM', checkOut: '05:05 PM', status: 'Late' },
  ];

  const handleCheckIn = async () => {
    const res = await attendanceService.checkIn();
    setMsg(res.message || 'Check in recorded!');
  };

  const handleCheckOut = async () => {
    const res = await attendanceService.checkOut();
    setMsg(res.message || 'Check out recorded!');
  };

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Attendance Log</h1>
          
          {msg && <div style={{ color: '#0D9488', fontWeight: 600, marginBottom: '16px' }}>{msg}</div>}

          <Card title="Today's Actions">
            <div style={{ display: 'flex', gap: '12px' }}>
              <Button onClick={handleCheckIn}>Check In</Button>
              <Button variant="secondary" onClick={handleCheckOut}>Check Out</Button>
            </div>
          </Card>

          <Card title="Recent Attendance Records">
            <Table
              headers={['Date', 'Check In', 'Check Out', 'Status']}
              data={sampleRecords}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px' }}>{row.date}</td>
                  <td style={{ padding: '12px 16px' }}>{row.checkIn}</td>
                  <td style={{ padding: '12px 16px' }}>{row.checkOut}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{
                      backgroundColor: row.status === 'Present' ? '#DCFCE7' : '#FEF3C7',
                      color: row.status === 'Present' ? '#166534' : '#92400E',
                      padding: '2px 8px',
                      borderRadius: '12px',
                      fontSize: '12px',
                      fontWeight: 600
                    }}>
                      {row.status}
                    </span>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default Attendance;
