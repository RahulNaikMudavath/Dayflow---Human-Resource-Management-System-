import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import { useAuth } from '../../../context/AuthContext';

const Profile = () => {
  const { user } = useAuth();

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>My Profile</h1>
          <Card title="Personal Information">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', fontSize: '14px' }}>
              <div><strong>Email:</strong> {user?.email}</div>
              <div><strong>Role:</strong> {user?.role}</div>
              <div><strong>First Name:</strong> {user?.firstName || 'John'}</div>
              <div><strong>Last Name:</strong> {user?.lastName || 'Doe'}</div>
              <div><strong>Department:</strong> Engineering</div>
              <div><strong>Designation:</strong> Software Engineer</div>
            </div>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default Profile;
