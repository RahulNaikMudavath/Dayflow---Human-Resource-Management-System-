import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Table from '../../../components/Table';
import Button from '../../../components/Button';
import { Download } from 'lucide-react';

const Payroll = () => {
  const payslips = [
    { month: 'August 2026', basic: '$75,000', bonus: '$5,000', deductions: '$2,000', net: '$78,000', status: 'Paid' }
  ];

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>My Payslips</h1>
          <Card title="Monthly Salary Records">
            <Table
              headers={['Month / Year', 'Basic Salary', 'Bonuses', 'Deductions', 'Net Salary', 'Status', 'Action']}
              data={payslips}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px' }}>{row.month}</td>
                  <td style={{ padding: '12px 16px' }}>{row.basic}</td>
                  <td style={{ padding: '12px 16px' }}>{row.bonus}</td>
                  <td style={{ padding: '12px 16px' }}>{row.deductions}</td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.net}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '2px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}>
                      {row.status}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <Button variant="outline" style={{ padding: '4px 8px', fontSize: '12px' }}>
                      <Download size={14} /> PDF
                    </Button>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default Payroll;
