import React, { useState } from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import Table from '../../../components/Table';
import Modal from '../../../components/Modal';

const LeaveRequests = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [leaveType, setLeaveType] = useState('casual');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');

  const leaves = [
    { type: 'Casual Leave', dates: '2026-08-27 to 2026-08-29', reason: 'Family event', status: 'Pending' }
  ];

  const handleApply = (e) => {
    e.preventDefault();
    setIsModalOpen(false);
    alert('Leave request submitted!');
  };

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A' }}>My Leave Requests</h1>
            <Button onClick={() => setIsModalOpen(true)}>Apply for Leave</Button>
          </div>

          <Card title="Leave History">
            <Table
              headers={['Leave Type', 'Dates', 'Reason', 'Status']}
              data={leaves}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px' }}>{row.type}</td>
                  <td style={{ padding: '12px 16px' }}>{row.dates}</td>
                  <td style={{ padding: '12px 16px' }}>{row.reason}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ backgroundColor: '#FEF3C7', color: '#92400E', padding: '2px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}>
                      {row.status}
                    </span>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>

          <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Apply for Leave">
            <form onSubmit={handleApply}>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>Leave Type</label>
                <select value={leaveType} onChange={(e) => setLeaveType(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #CBD5E1' }}>
                  <option value="casual">Casual Leave</option>
                  <option value="sick">Sick Leave</option>
                  <option value="earned">Earned Leave</option>
                </select>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>Start Date</label>
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #CBD5E1' }} />
              </div>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>End Date</label>
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #CBD5E1' }} />
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>Reason</label>
                <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={3} required style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #CBD5E1' }} />
              </div>
              <Button type="submit" style={{ width: '100%' }}>Submit Application</Button>
            </form>
          </Modal>
        </main>
      </div>
    </div>
  );
};

export default LeaveRequests;
