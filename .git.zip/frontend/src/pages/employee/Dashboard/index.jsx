import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import { Clock, Calendar, CheckCircle, DollarSign } from 'lucide-react';

const Dashboard = () => {
  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Employee Dashboard</h1>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '24px' }}>
            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Clock color="#0D9488" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Today Status</div>
                  <div style={{ fontSize: '18px', fontWeight: 600 }}>Checked In (09:00 AM)</div>
                </div>
              </div>
            </Card>

            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Calendar color="#D97706" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Leave Balance</div>
                  <div style={{ fontSize: '18px', fontWeight: 600 }}>14 Days</div>
                </div>
              </div>
            </Card>

            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <DollarSign color="#16A34A" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Latest Salary</div>
                  <div style={{ fontSize: '18px', fontWeight: 600 }}>$78,000</div>
                </div>
              </div>
            </Card>
          </div>

          <Card title="Quick Announcements">
            <p style={{ color: '#475569', fontSize: '14px' }}>Welcome to Dayflow HRMS! Please ensure your daily attendance is logged accurately.</p>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
