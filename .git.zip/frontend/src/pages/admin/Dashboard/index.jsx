import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import { Users, UserCheck, Clock, FileCheck } from 'lucide-react';

const AdminDashboard = () => {
  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Admin Overview</h1>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '24px' }}>
            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Users color="#0D9488" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Total Employees</div>
                  <div style={{ fontSize: '20px', fontWeight: 700 }}>48</div>
                </div>
              </div>
            </Card>

            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <UserCheck color="#16A34A" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Present Today</div>
                  <div style={{ fontSize: '20px', fontWeight: 700 }}>42</div>
                </div>
              </div>
            </Card>

            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <Clock color="#D97706" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Pending Leaves</div>
                  <div style={{ fontSize: '20px', fontWeight: 700 }}>5</div>
                </div>
              </div>
            </Card>

            <Card>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <FileCheck color="#2563EB" size={32} />
                <div>
                  <div style={{ fontSize: '12px', color: '#475569' }}>Payroll Status</div>
                  <div style={{ fontSize: '20px', fontWeight: 700 }}>Ready</div>
                </div>
              </div>
            </Card>
          </div>

          <Card title="System Management">
            <p style={{ color: '#475569', fontSize: '14px' }}>Use the navigation bar on the left to manage employees, review attendance logs, process leave approvals, and run monthly payrolls.</p>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
