import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Table from '../../../components/Table';

const AdminAttendance = () => {
  const allLogs = [
    { employee: 'John Doe', date: '2026-08-22', checkIn: '09:00 AM', checkOut: '05:00 PM', status: 'Present' },
    { employee: 'System Admin', date: '2026-08-22', checkIn: '08:45 AM', checkOut: '05:30 PM', status: 'Present' },
  ];

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Organization Attendance Logs</h1>
          <Card title="Live Attendance Log">
            <Table
              headers={['Employee', 'Date', 'Check In', 'Check Out', 'Status']}
              data={allLogs}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.employee}</td>
                  <td style={{ padding: '12px 16px' }}>{row.date}</td>
                  <td style={{ padding: '12px 16px' }}>{row.checkIn}</td>
                  <td style={{ padding: '12px 16px' }}>{row.checkOut}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '2px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}>
                      {row.status}
                    </span>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default AdminAttendance;
