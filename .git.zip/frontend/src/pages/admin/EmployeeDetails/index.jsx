import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import { ArrowLeft } from 'lucide-react';

const EmployeeDetails = () => {
  const { id } = useParams();

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <div style={{ marginBottom: '16px' }}>
            <Link to="/admin/employees">
              <Button variant="outline" style={{ padding: '6px 12px', fontSize: '13px' }}>
                <ArrowLeft size={16} /> Back to List
              </Button>
            </Link>
          </div>

          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Employee Details (#{id})</h1>

          <Card title="Profile Overview">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', fontSize: '14px' }}>
              <div><strong>Name:</strong> John Doe</div>
              <div><strong>Email:</strong> john.doe@dayflow.com</div>
              <div><strong>Department:</strong> Engineering</div>
              <div><strong>Designation:</strong> Software Engineer</div>
              <div><strong>Date of Joining:</strong> 2024-02-15</div>
              <div><strong>Salary:</strong> $75,000</div>
            </div>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default EmployeeDetails;
