import React, { useState } from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Button from '../../../components/Button';
import Table from '../../../components/Table';
import { Play } from 'lucide-react';

const AdminPayroll = () => {
  const [status, setStatus] = useState('');
  const currentPayrolls = [
    { employee: 'John Doe', month: 'August 2026', basic: '$75,000', net: '$78,000', status: 'Pending' }
  ];

  const handleRunPayroll = () => {
    setStatus('Payroll processing initiated for August 2026');
  };

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A' }}>Payroll Management</h1>
            <Button onClick={handleRunPayroll}>
              <Play size={16} /> Run Monthly Payroll
            </Button>
          </div>

          {status && <div style={{ color: '#0D9488', fontWeight: 600, marginBottom: '16px' }}>{status}</div>}

          <Card title="Current Period Summary">
            <Table
              headers={['Employee', 'Period', 'Basic Salary', 'Net Salary', 'Status']}
              data={currentPayrolls}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.employee}</td>
                  <td style={{ padding: '12px 16px' }}>{row.month}</td>
                  <td style={{ padding: '12px 16px' }}>{row.basic}</td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.net}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ backgroundColor: '#FEF3C7', color: '#92400E', padding: '2px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}>
                      {row.status}
                    </span>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default AdminPayroll;
