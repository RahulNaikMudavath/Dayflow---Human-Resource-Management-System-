import React from 'react';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Table from '../../../components/Table';
import Button from '../../../components/Button';
import { Check, X } from 'lucide-react';

const LeaveApprovals = () => {
  const pendingLeaves = [
    { id: 1, employee: 'John Doe', type: 'Casual Leave', dates: '2026-08-27 to 2026-08-29', reason: 'Family event' }
  ];

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Leave Approvals</h1>
          <Card title="Pending Applications">
            <Table
              headers={['Employee', 'Leave Type', 'Dates', 'Reason', 'Actions']}
              data={pendingLeaves}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.employee}</td>
                  <td style={{ padding: '12px 16px' }}>{row.type}</td>
                  <td style={{ padding: '12px 16px' }}>{row.dates}</td>
                  <td style={{ padding: '12px 16px' }}>{row.reason}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <Button style={{ padding: '4px 8px', fontSize: '12px' }}>
                        <Check size={14} /> Approve
                      </Button>
                      <Button variant="danger" style={{ padding: '4px 8px', fontSize: '12px' }}>
                        <X size={14} /> Reject
                      </Button>
                    </div>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default LeaveApprovals;
