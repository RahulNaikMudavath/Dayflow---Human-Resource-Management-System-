import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../../components/Navbar';
import Sidebar from '../../../components/Sidebar';
import Card from '../../../components/Card';
import Table from '../../../components/Table';
import Button from '../../../components/Button';
import { Eye } from 'lucide-react';

const Employees = () => {
  const employeeList = [
    { id: 1, name: 'System Admin', department: 'Management', designation: 'HR Admin', email: 'admin@dayflow.com' },
    { id: 2, name: 'John Doe', department: 'Engineering', designation: 'Software Engineer', email: 'john.doe@dayflow.com' }
  ];

  return (
    <div>
      <Navbar />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '24px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#134E4A', marginBottom: '20px' }}>Employee Directory</h1>
          <Card title="All Staff Members">
            <Table
              headers={['ID', 'Name', 'Department', 'Designation', 'Email', 'Action']}
              data={employeeList}
              renderRow={(row, idx) => (
                <React.Fragment key={idx}>
                  <td style={{ padding: '12px 16px' }}>#{row.id}</td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>{row.name}</td>
                  <td style={{ padding: '12px 16px' }}>{row.department}</td>
                  <td style={{ padding: '12px 16px' }}>{row.designation}</td>
                  <td style={{ padding: '12px 16px' }}>{row.email}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <Link to={`/admin/employees/${row.id}`}>
                      <Button variant="outline" style={{ padding: '4px 8px', fontSize: '12px' }}>
                        <Eye size={14} /> View
                      </Button>
                    </Link>
                  </td>
                </React.Fragment>
              )}
            />
          </Card>
        </main>
      </div>
    </div>
  );
};

export default Employees;
