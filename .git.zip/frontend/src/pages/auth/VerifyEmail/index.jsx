import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../../../components/Card';
import Button from '../../../components/Button';

const VerifyEmail = () => {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F0FDFA' }}>
      <Card style={{ width: '100%', maxWidth: '400px', textAlign: 'center' }}>
        <h2 style={{ color: '#0D9488', marginBottom: '12px' }}>Check Your Email</h2>
        <p style={{ color: '#475569', fontSize: '14px', marginBottom: '24px' }}>
          We have sent a verification link to your registered email address. Please verify your account to proceed.
        </p>
        <Link to="/login">
          <Button variant="outline">Back to Login</Button>
        </Link>
      </Card>
    </div>
  );
};

export default VerifyEmail;
