import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';
import RoleRoute from './RoleRoute';

// Auth Pages
import Login from '../pages/auth/Login';
import Signup from '../pages/auth/Signup';
import VerifyEmail from '../pages/auth/VerifyEmail';

// Employee Pages
import EmployeeDashboard from '../pages/employee/Dashboard';
import Profile from '../pages/employee/Profile';
import EmployeeAttendance from '../pages/employee/Attendance';
import LeaveRequests from '../pages/employee/LeaveRequests';
import EmployeePayroll from '../pages/employee/Payroll';

// Admin Pages
import AdminDashboard from '../pages/admin/Dashboard';
import EmployeesList from '../pages/admin/Employees';
import EmployeeDetails from '../pages/admin/EmployeeDetails';
import AdminAttendance from '../pages/admin/Attendance';
import LeaveApprovals from '../pages/admin/LeaveApprovals';
import AdminPayroll from '../pages/admin/Payroll';

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Auth Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/verify-email" element={<VerifyEmail />} />

      {/* Protected Routes */}
      <Route element={<ProtectedRoute />}>
        {/* Employee Routes */}
        <Route path="/dashboard" element={<EmployeeDashboard />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/attendance" element={<EmployeeAttendance />} />
        <Route path="/leaves" element={<LeaveRequests />} />
        <Route path="/payroll" element={<EmployeePayroll />} />

        {/* Admin Routes */}
        <Route element={<RoleRoute allowedRoles={['admin', 'hr']} />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/employees" element={<EmployeesList />} />
          <Route path="/admin/employees/:id" element={<EmployeeDetails />} />
          <Route path="/admin/attendance" element={<AdminAttendance />} />
          <Route path="/admin/leaves" element={<LeaveApprovals />} />
          <Route path="/admin/payroll" element={<AdminPayroll />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
};

export default AppRoutes;
