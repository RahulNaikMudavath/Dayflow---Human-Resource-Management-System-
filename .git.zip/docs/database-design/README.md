# Database Design

This directory contains database documentation, ER diagrams, and relational schema details for Dayflow HRMS.

## Tables Overview
- `users`: Core authentication table supporting credentials & roles (`admin`, `employee`, `hr`).
- `employees`: Extended employee details, department, designation, salary.
- `attendance`: Daily clock-in/out records and status tracking.
- `leave_requests`: Leave applications, type, dates, reason, and approval status.
- `payroll`: Monthly salary breakdowns, bonuses, deductions, and net payouts.
