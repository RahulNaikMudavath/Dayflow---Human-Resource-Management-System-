# Architecture & Workflow Diagrams

This directory stores visual flowcharts, sequence diagrams, and architecture designs for Dayflow HRMS.

- System Architecture Diagram
- Role-based Access Control (RBAC) Flow
- Leave Request Approval Workflow
- Payroll Processing Sequence Diagram
