# API Documentation

Dayflow HRMS REST API Endpoint Specifications.

## Base URL
`http://localhost:5000/api`

## Modules & Endpoints

### Auth (`/auth`)
- `POST /auth/login` - Authenticate user & get JWT token
- `POST /auth/signup` - Register a new employee user
- `POST /auth/verify-email` - Verify user email

### Employees (`/employees`)
- `GET /employees` - Get list of all employees (Admin)
- `GET /employees/:id` - Get specific employee profile
- `PUT /employees/:id` - Update employee profile

### Attendance (`/attendance`)
- `POST /attendance/check-in` - Record check-in timestamp
- `POST /attendance/check-out` - Record check-out timestamp
- `GET /attendance/my-records` - Get employee attendance history
- `GET /attendance/all` - Get all attendance records (Admin)

### Leave Requests (`/leaves`)
- `POST /leaves` - Apply for leave
- `GET /leaves/my-leaves` - Get employee leave history
- `GET /leaves/pending` - Get pending leave requests (Admin)
- `PUT /leaves/:id/status` - Approve / Reject leave (Admin)

### Payroll (`/payroll`)
- `GET /payroll/my-slips` - Get employee payslips
- `POST /payroll/generate` - Process monthly payroll (Admin)
