# Dayflow - Human Resource Management System (HRMS)

Dayflow HRMS is a modern, full-stack Human Resource Management System built to streamline employee management, attendance tracking, leave processing, and payroll operations for organizations.

## 🚀 Repository Architecture

```text
Dayflow-HRMS/
├── frontend/             # Modern React Frontend (Vite + Component Architecture)
├── backend/              # Node.js + Express REST API Server
├── database/             # PostgreSQL / MySQL SQL Schemas, Seeds & Migrations
└── docs/                 # System Documentation, API Specs & Diagrams
```

## 🛠️ Tech Stack

- **Frontend**: React, React Router, Context API, Modern CSS / Design Tokens
- **Backend**: Node.js, Express.js, JWT Authentication, Middleware Architecture
- **Database**: SQL (PostgreSQL / MySQL compatible schema)

## 📦 Setup & Installation

### Backend Setup
```bash
cd backend
npm install
npm run dev
```

### Frontend Setup
```bash
cd frontend
npm install
npm run dev
```

## 📄 Documentation

Check out the [`docs/`](./docs) folder for detailed API specifications, database design diagrams, and system requirements.
