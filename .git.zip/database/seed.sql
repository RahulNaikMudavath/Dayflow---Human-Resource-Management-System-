-- Dayflow HRMS Seed Data

-- Insert Sample Admin User (password: AdminPass123!)
INSERT INTO users (email, password_hash, role, is_verified) 
VALUES ('admin@dayflow.com', '$2b$10$e8W/R5Y9mJ8iT6zXG4.NfeK3G6g.gA0mP.gE.vW1q2r3s4t5u6v7w', 'admin', TRUE);

-- Insert Sample Employee User (password: EmpPass123!)
INSERT INTO users (email, password_hash, role, is_verified) 
VALUES ('john.doe@dayflow.com', '$2b$10$e8W/R5Y9mJ8iT6zXG4.NfeK3G6g.gA0mP.gE.vW1q2r3s4t5u6v7w', 'employee', TRUE);

-- Insert Sample Employee Profiles
INSERT INTO employees (user_id, first_name, last_name, department, designation, phone, date_of_joining, salary)
VALUES 
(1, 'System', 'Admin', 'Management', 'HR Admin', '+1234567890', '2024-01-01', 95000.00),
(2, 'John', 'Doe', 'Engineering', 'Software Engineer', '+1987654321', '2024-02-15', 75000.00);

-- Insert Sample Attendance
INSERT INTO attendance (employee_id, date, check_in, check_out, status)
VALUES 
(2, CURRENT_DATE, '09:00:00', '17:00:00', 'present');

-- Insert Sample Leave Request
INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status)
VALUES 
(2, 'casual', CURRENT_DATE + INTERVAL '5 days', CURRENT_DATE + INTERVAL '7 days', 'Family vacation', 'pending');
